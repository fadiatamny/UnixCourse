#include <stdio.h>
#include <string.h>

#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <dirent.h>
#include <sys/types.h>

void changeDir(char *path)
{
    if (chdir(path))
    {
        printf("Error: %s\n", strerror(errno));
    }
}

void ls(char *path)
{
    DIR *directory;
    struct dirent *ent;
    char _path[256] = {0};
    if (strlen(path) == 0)
        getcwd(_path, 256);
    else
        strcpy(_path, path);
    if ((directory = opendir(_path)) == NULL)
    {
        fprintf(stderr, "Could not open file: %s\n", _path);
        return;
    }
    while ((ent = readdir(directory)) != NULL)
        printf("%s\n", ent->d_name);
}

int main(int argc, char const *argv[])
{
    while (1)
    {
        char buf[512] = {0};
        char path[256] = {0};
        getcwd(path, 256);
        printf(" %s>", path);

        fgets(buf, 512, stdin);
        buf[strlen(buf) - 1] = 0;

        if (strncmp(buf, "ls", 2) == 0)
        {
            ls(buf + 3);
        }
        else if (strncmp(buf, "cd", 2) == 0)
        {
            changeDir(buf + 3);
        }
        else
            system(buf);
    }
    return 0;
}
