#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define BUF_SIZE 1024

void readToSTDOut(int fd)
{
    int n;
    char buffer[BUF_SIZE];
    while ((n = read(fd, buffer, BUF_SIZE)) > 0)
        if (write(STDOUT_FILENO, buffer, n) != n)
            return;
    close(fd);
}

int main(int argc, char const *argv[])
{
    // if (argc > 1 && argv[1][0] != '-')
    // {
    for (int i = 1; i < argc; i++)
    {
        int fd;
        if (argv[i][0] != '-')
        {
            fd = open(argv[i], O_RDONLY);
            
        }
        else
            fd = STDIN_FILENO;

        readToSTDOut(fd);
    }
    if (argc == 1)
    {
        readToSTDOut(STDIN_FILENO);
    }
    // }
    return 0;
}
