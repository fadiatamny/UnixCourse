#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/wait.h>
int main(int argc, char const *argv[])
{
    printf("(%d)about to clone myself\n", getpid());
    pid_t pid = fork();
    if (pid)
    {
        waitpid(pid,NULL, 0);
        printf("(%d) %d i'm your father\n", getpid(), pid);
    }
    else
    {
        printf("(%d) i'm the child\n", getpid());
    }

    printf("(%d) We are family, i got all my processes with me\n", getpid());
    return 0;
}
