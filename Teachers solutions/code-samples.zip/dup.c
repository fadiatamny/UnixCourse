#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

int main(int argc, char const *argv[])
{
    char *path = "output.log";
    printf("where will this print to ?");
    int out_fd = open(path, O_WRONLY | O_CREAT | O_TRUNC);
    if (out_fd < 0)
        perror("open");
    if (close(STDOUT_FILENO) < 0)
        perror("close");
    // int fd = dup(out_fd);
    // if (fd != STDOUT_FILENO)
    //     return 1;
    // puts("My Message\n");
    // close(out_fd);
    // close(fd);
    return 0;
}
