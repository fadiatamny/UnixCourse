#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define BUF_SIZE 1024

void copyFromTo(const char* from, const char* to)
{
    int n;
    char buffer[BUF_SIZE];
    struct stat originalPerms;
    stat(from, &originalPerms);
    int from_fd = open(from, O_RDONLY);
    int to_fd = open(to, O_WRONLY | O_CREAT | O_TRUNC, originalPerms.st_mode);
    while ((n = read(from_fd, buffer, BUF_SIZE)) > 0)
        if (write(to_fd, buffer, n) != n)
            return;
    
    close(from_fd);
    close(to_fd);
}

int main(int argc, char const *argv[])
{
    if (argc < 3)
        exit(1);
    if (!strcmp(argv[1], argv[2]))
    {
        printf("%s: 'files.c' and 'files.c' are the same file", argv[0]);
        exit(1);
    }

    struct stat s;
    char targetPath[256] = {0};
    stat(argv[2], &s);

    if (S_ISDIR(s.st_mode))
    {
        strcat(targetPath, argv[2]);
        targetPath[strlen(targetPath)] = '/';
        strcat(targetPath, argv[1]);
    }
    else
        strcat(targetPath, argv[2]);

    copyFromTo(argv[1], targetPath);

    return 0;
}
